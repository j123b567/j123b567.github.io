# STM32F407: reading CCM and SRAM under RDP Level 1

Example firmware and scripts for the article
https://www.jaybee.cz/software/stm32f407-ccm-readout-rdp1/

Tested on STM32F407G-DISC1 (STM32F407VGT6 rev 2, on-board ST-LINK/V2-A) with
PlatformIO (`ststm32`, `stm32cube` framework, LL drivers) and OpenOCD 0.11.

    firmware/                PlatformIO project (pio run -t upload)
    tools/ocd.sh             OpenOCD wrapper (OCD=... to override the path)
    tools/read-evidence.py   attach without reset/halt, read and decode registers, records, patterns
    tools/dump-ram.sh        dump whole CCM (64 KiB) and SRAM (128 KiB)

Set RDP1:   tools/ocd.sh -c init -c "reset halt" -c "stm32f2x lock 0" -c shutdown
Back to 0:  tools/ocd.sh -c init -c halt -c "stm32f2x unlock 0" -c shutdown
Both need a power-on reset afterwards. Do not set RDP Level 2 on a test board:
it is irreversible and disables SWD for good. It is meant for production devices.

Note: PlatformIO's "RAM used" summary does not include CCM. Check the
addresses with arm-none-eabi-nm after each build.

The linker script is STMicroelectronics' CubeIDE-generated script with added
NOLOAD sections; its original license header is kept.
