/*
 * Evidence collection for read-out under RDP Level 1.
 *
 * Initialized counters g_sram_counter (.data) and g_ccm_counter (.ccmram), plus:
 *   - known test patterns written on every boot (for dump integrity checks):
 *       g_sram_pattern[256] in .noinit    (SRAM), word i = 0x5A5A0000 | i
 *       g_ccm_pattern[256]  in .ccmnoinit (CCM),  word i = 0xCC5A0000 | i
 *       backup SRAM 0x40024000, 256 words,        word i = 0xBB5A0000 | i
 *     (backup SRAM clock stays enabled, so a debugger read is a real access)
 *   - optional run-from-RAM main loop: hold user button B1 (PA0) during boot.
 *       mode 0 (flash loop): LED steps 0,3,2,1 every 250 ms, code runs from flash
 *       mode 1 (RAM loop):   LED steps 0,1,2,3 every 100 ms, loop runs from SRAM
 *                            (.RamFunc) and does not touch flash at all
 *
 * Persistent records (NOLOAD sections, survive system reset, lost on power-on reset):
 *   g_sram_persist in .noinit, g_ccm_persist in .ccmnoinit.
 */
#include "stm32f4xx_ll_bus.h"
#include "stm32f4xx_ll_gpio.h"
#include "stm32f4xx_ll_pwr.h"
#include "stm32f4xx_ll_rcc.h"
#include "stm32f4xx_ll_utils.h"

#define LED_PINS (LL_GPIO_PIN_12 | LL_GPIO_PIN_13 | LL_GPIO_PIN_14 | LL_GPIO_PIN_15)

#define SRAM_PERSIST_MAGIC 0x5EA1AB1EU
#define CCM_PERSIST_MAGIC  0xCC4EC0DEU
#define CSR_HISTORY_LEN    8U
#define NOT_SEEN           0xFFFFFFFFU

#define PATTERN_WORDS      256U
#define SRAM_PATTERN_BASE  0x5A5A0000U
#define CCM_PATTERN_BASE   0xCC5A0000U
#define BKP_PATTERN_BASE   0xBB5A0000U

#define MODE_FLASH_LOOP    0U
#define MODE_RAM_LOOP      1U

typedef struct {
    uint32_t magic;
    uint32_t boot_count;
    uint32_t csr_history[CSR_HISTORY_LEN]; /* RCC_CSR at boot, index boot_count % 8 */
    uint32_t loop_counter;                 /* not reset on boot */
    uint32_t loop_at_boot;                 /* loop_counter value when this boot started */
    uint32_t debugen_loop;                 /* loop_counter when C_DEBUGEN was first seen */
    uint32_t dhcsr_at_boot;
    uint32_t mode;                         /* MODE_FLASH_LOOP or MODE_RAM_LOOP */
} persist_t;

/* Linker script symbols for the .ccmram section. */
extern uint32_t _siccmram, _sccmram, _eccmram;

volatile uint32_t g_sram_counter = 0xC0DE0000U;

__attribute__((section(".ccmram")))
volatile uint32_t g_ccm_counter = 0xCC0D0000U;

__attribute__((section(".noinit")))
volatile persist_t g_sram_persist;

__attribute__((section(".ccmnoinit")))
volatile persist_t g_ccm_persist;

__attribute__((section(".noinit")))
volatile uint32_t g_sram_pattern[PATTERN_WORDS];

__attribute__((section(".ccmnoinit")))
volatile uint32_t g_ccm_pattern[PATTERN_WORDS];

static void ccmram_init(void)
{
    const uint32_t *src = &_siccmram;
    for (uint32_t *dst = &_sccmram; dst < &_eccmram; ) {
        *dst++ = *src++;
    }
}

static void pattern_fill(volatile uint32_t *dst, uint32_t base)
{
    for (uint32_t i = 0U; i < PATTERN_WORDS; i++) {
        dst[i] = base | i;
    }
}

static void persist_boot(volatile persist_t *p, uint32_t magic, uint32_t csr, uint32_t dhcsr, uint32_t mode)
{
    if (p->magic != magic) {
        /* First boot after power-on: memory content is random. */
        p->magic = magic;
        p->boot_count = 0U;
        for (uint32_t i = 0U; i < CSR_HISTORY_LEN; i++) {
            p->csr_history[i] = 0U;
        }
        p->loop_counter = 0U;
        p->debugen_loop = NOT_SEEN;
    }
    p->boot_count++;
    p->csr_history[p->boot_count % CSR_HISTORY_LEN] = csr;
    p->loop_at_boot = p->loop_counter;
    p->dhcsr_at_boot = dhcsr;
    p->mode = mode;
}

/* Always inlined, so the RAM loop does not call any function located in flash. */
static inline __attribute__((always_inline)) void persist_loop(volatile persist_t *p, uint32_t dhcsr)
{
    p->loop_counter++;
    if ((dhcsr & CoreDebug_DHCSR_C_DEBUGEN_Msk) != 0U && p->debugen_loop == NOT_SEEN) {
        p->debugen_loop = p->loop_counter;
    }
}

static inline __attribute__((always_inline)) void delay_ms_inline(uint32_t ms)
{
    /* Same method as LL_mDelay: SysTick runs with 1 ms period, poll COUNTFLAG. */
    while (ms != 0U) {
        if ((SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk) != 0U) {
            ms--;
        }
    }
}

/*
 * Main loop executed from SRAM (.RamFunc is copied with .data by the startup code).
 * Interrupts stay disabled (vector table is in flash); no calls, no flash constants.
 */
__attribute__((section(".RamFunc"), noinline, long_call))
static void ram_loop(void)
{
    for (;;) {
        const uint32_t dhcsr_now = CoreDebug->DHCSR;
        persist_loop(&g_sram_persist, dhcsr_now);
        persist_loop(&g_ccm_persist, dhcsr_now);
        g_sram_counter += 1U;
        g_ccm_counter += 2U;
        GPIOD->BSRR = LED_PINS << 16;
        GPIOD->BSRR = LL_GPIO_PIN_12 << (g_sram_counter & 3U);
        delay_ms_inline(100U);
    }
}

static void flash_loop(void)
{
    /*
     * SRAM counter steps by 1, CCM counter by 2 per pass, so the sum steps by 3:
     * the LED visits all four positions, one step every 250 ms.
     */
    static const uint32_t seq[] = { LL_GPIO_PIN_12, LL_GPIO_PIN_13, LL_GPIO_PIN_14, LL_GPIO_PIN_15 };
    for (;;) {
        const uint32_t dhcsr_now = CoreDebug->DHCSR;
        persist_loop(&g_sram_persist, dhcsr_now);
        persist_loop(&g_ccm_persist, dhcsr_now);
        g_sram_counter += 1U;
        g_ccm_counter += 2U;
        LL_GPIO_ResetOutputPin(GPIOD, LED_PINS);
        LL_GPIO_SetOutputPin(GPIOD, seq[(g_sram_counter + g_ccm_counter) & 3U]);
        LL_mDelay(250);
    }
}

int main(void)
{
    const uint32_t csr = RCC->CSR;
    const uint32_t dhcsr = CoreDebug->DHCSR;
    LL_RCC_ClearResetFlags();

    /* User button B1 on PA0 (active high, external pull-down) selects the RAM loop. */
    LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOA);
    LL_GPIO_SetPinMode(GPIOA, LL_GPIO_PIN_0, LL_GPIO_MODE_INPUT);
    const uint32_t mode = LL_GPIO_IsInputPinSet(GPIOA, LL_GPIO_PIN_0) ? MODE_RAM_LOOP : MODE_FLASH_LOOP;

    persist_boot(&g_sram_persist, SRAM_PERSIST_MAGIC, csr, dhcsr, mode);
    persist_boot(&g_ccm_persist, CCM_PERSIST_MAGIC, csr, dhcsr, mode);

    ccmram_init();
    pattern_fill(g_sram_pattern, SRAM_PATTERN_BASE);
    pattern_fill(g_ccm_pattern, CCM_PATTERN_BASE);

    /* Backup SRAM: PWR clock + DBP for write access, BKPSRAM clock stays on. */
    LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_PWR);
    LL_PWR_EnableBkUpAccess();
    LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_BKPSRAM);
    pattern_fill((volatile uint32_t *)BKPSRAM_BASE, BKP_PATTERN_BASE);

    LL_Init1msTick(16000000U);

    LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOD);

    LL_GPIO_InitTypeDef gpio = {
        .Pin = LED_PINS,
        .Mode = LL_GPIO_MODE_OUTPUT,
        .Speed = LL_GPIO_SPEED_FREQ_LOW,
        .OutputType = LL_GPIO_OUTPUT_PUSHPULL,
        .Pull = LL_GPIO_PULL_NO,
    };
    LL_GPIO_Init(GPIOD, &gpio);

    if (mode == MODE_RAM_LOOP) {
        ram_loop();
    }
    flash_loop();
}
