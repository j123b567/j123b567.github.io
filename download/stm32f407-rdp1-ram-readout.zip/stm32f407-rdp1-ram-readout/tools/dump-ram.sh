#!/bin/sh
# Attach without reset and dump the whole CCM (64 KiB) and SRAM (128 KiB).
# Usage: tools/dump-ram.sh [output-prefix]
OUT=${1:-dump}
exec "$(dirname "$0")/ocd.sh" -c init \
    -c "dump_image $OUT-ccm.bin 0x10000000 0x10000" \
    -c "dump_image $OUT-sram.bin 0x20000000 0x20000" \
    -c shutdown
