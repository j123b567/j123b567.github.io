#!/bin/sh
# Run OpenOCD from PlatformIO packages against STM32F407G-DISC1 (on-board ST-LINK/V2-A).
# Usage: tools/ocd.sh -c "init" -c "..." -c "shutdown"
OCD=${OCD:-$HOME/.platformio/packages/tool-openocd}
exec "$OCD/bin/openocd" -s "$OCD/openocd/scripts" -f interface/stlink.cfg -f target/stm32f4x.cfg "$@"
