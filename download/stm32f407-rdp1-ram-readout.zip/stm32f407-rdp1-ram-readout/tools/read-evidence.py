#!/usr/bin/env python3
"""Read firmware evidence via OpenOCD (attach without reset/halt) and decode it.

Session 1 (no halt): debug/fault registers, RCC, counters, persistent records,
counters again after 1 s (liveness), SRAM and CCM test patterns.
Session 2 (separate, may fail under RDP1): backup SRAM test pattern.

Usage: tools/read-evidence.py <logfile> [elf]
Addresses are taken from the ELF symbol table (arm-none-eabi-nm).
The raw OpenOCD output is appended to <logfile>.raw.
"""
import os
import re
import subprocess
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
NM = os.path.expanduser("~/.platformio/packages/toolchain-gccarmnoneeabi/bin/arm-none-eabi-nm")
ELF = os.path.join(TOOLS, "..", "firmware/.pio/build/disco_f407vg/firmware.elf")
FIELDS = ["magic", "boot_count"] + [f"csr[{i}]" for i in range(8)] + \
         ["loop_counter", "loop_at_boot", "debugen_loop", "dhcsr_at_boot", "mode"]
PATTERN_WORDS = 256
BKPSRAM = 0x40024000
CSR_FLAGS = [(31, "LPWR"), (30, "WWDG"), (29, "IWDG"), (28, "SFT"), (27, "POR"), (26, "PIN"), (25, "BOR")]
DHCSR_FLAGS = [(0, "C_DEBUGEN"), (1, "C_HALT"), (16, "S_REGRDY"), (17, "S_HALT"), (18, "S_SLEEP"),
               (19, "S_LOCKUP"), (24, "S_RESET_ST"), (25, "S_RETIRE_ST")]
CFSR_FLAGS = [(0, "IACCVIOL"), (1, "DACCVIOL"), (3, "MUNSTKERR"), (4, "MSTKERR"), (7, "MMARVALID"),
              (8, "IBUSERR"), (9, "PRECISERR"), (10, "IMPRECISERR"), (11, "UNSTKERR"), (12, "STKERR"),
              (15, "BFARVALID"), (16, "UNDEFINSTR"), (17, "INVSTATE"), (18, "INVPC"), (19, "NOCP"),
              (24, "UNALIGNED"), (25, "DIVBYZERO")]
HFSR_FLAGS = [(1, "VECTTBL"), (30, "FORCED"), (31, "DEBUGEVT")]
DFSR_FLAGS = [(0, "HALTED"), (1, "BKPT"), (2, "DWTTRAP"), (3, "VCATCH"), (4, "EXTERNAL")]
FLAG_TABLES = {"DHCSR": DHCSR_FLAGS, "RCC_CSR": CSR_FLAGS, "CFSR": CFSR_FLAGS, "HFSR": HFSR_FLAGS,
               "DFSR": DFSR_FLAGS}


def flags(value, table):
    return ",".join(name for bit, name in table if value & (1 << bit)) or "-"


def symbols(elf):
    out = subprocess.run([NM, elf], capture_output=True, text=True, check=True).stdout
    return {name: int(addr, 16) for addr, _, name in (l.split() for l in out.splitlines() if len(l.split()) == 3)}


def run_ocd(commands, raw_log):
    cmd = [os.path.join(TOOLS, "ocd.sh"), "-c", "init"]
    for c in commands:
        cmd += ["-c", c]
    cmd += ["-c", "shutdown"]
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    with open(raw_log, "a") as fh:
        fh.write(f"### exit={res.returncode} commands: {commands}\n{res.stdout}\n")
    # Each mdw prints one or more lines; keep them in order, grouped per command.
    blocks = []
    for line in res.stdout.splitlines():
        m = re.match(r"^0x([0-9a-f]{8}):((?: [0-9a-f]{8})+)", line)
        if m:
            blocks.append((int(m.group(1), 16), [int(w, 16) for w in m.group(2).split()]))
    return res.returncode, blocks


def words_from(blocks, start, count):
    """Collect `count` words starting at `start` from consecutive mdw output lines."""
    mem = {}
    for base, ws in blocks:
        for i, w in enumerate(ws):
            mem.setdefault(base + 4 * i, w)
    return [mem.get(start + 4 * i) for i in range(count)]


def split_blocks(blocks, marker_addr):
    """Split mdw output into first and second occurrence of reads starting at marker_addr."""
    idx = [i for i, (base, _) in enumerate(blocks) if base == marker_addr]
    if len(idx) < 2:
        return blocks, []
    return blocks[:idx[1]], blocks[idx[1]:]


def check_pattern(name, vals, base, out):
    bad = [(i, v) for i, v in enumerate(vals) if v != (base | i)]
    if all(v is None for v in vals):
        out.append(f"{name:16s} READ FAILED")
    elif not bad:
        out.append(f"{name:16s} OK, {len(vals)} words match 0x{base:08x}|i")
    else:
        i, v = bad[0]
        out.append(f"{name:16s} MISMATCH in {len(bad)} words, first at index {i}: "
                   + ("FAIL" if v is None else f"0x{v:08x}"))


def main():
    log = sys.argv[1]
    raw_log = log + ".raw"
    sym = symbols(sys.argv[2] if len(sys.argv) > 2 else ELF)
    regs = [("DHCSR", 0xE000EDF0), ("CFSR", 0xE000ED28), ("HFSR", 0xE000ED2C), ("DFSR", 0xE000ED30),
            ("MMFAR", 0xE000ED34), ("BFAR", 0xE000ED38), ("RCC_CSR", 0x40023874), ("RCC_AHB1ENR", 0x40023830),
            ("FLASH_OPTCR", 0x40023C14), ("GPIOD_ODR", 0x40020C14)]
    live = [("g_sram_counter", sym["g_sram_counter"], 1), ("g_ccm_counter", sym["g_ccm_counter"], 1),
            ("g_sram_persist", sym["g_sram_persist"], len(FIELDS)),
            ("g_ccm_persist", sym["g_ccm_persist"], len(FIELDS))]
    cmds = [f"mdw 0x{a:08x}" for _, a in regs]
    cmds += [f"mdw 0x{a:08x} {n}" for _, a, n in live]
    cmds += ["sleep 1000", "mdw 0xe000edf0", "mdw 0x40020c14"]
    cmds += [f"mdw 0x{a:08x} {n}" for _, a, n in live]
    cmds += [f"mdw 0x{sym['g_sram_pattern']:08x} {PATTERN_WORDS}", f"mdw 0x{sym['g_ccm_pattern']:08x} {PATTERN_WORDS}"]
    rc1, blocks = run_ocd(cmds, raw_log)
    first, second = split_blocks(blocks, sym["g_sram_counter"])

    out = [f"session 1 exit={rc1}"]
    for name, addr in regs:
        v = words_from(first, addr, 1)[0]
        extra = f"  [{flags(v, FLAG_TABLES[name])}]" if v is not None and name in FLAG_TABLES else ""
        out.append(f"{name:16s} @0x{addr:08x} = " + ("FAIL" if v is None else f"0x{v:08x}{extra}"))
    for label, blk in (("t=0", first), ("t=+1s", second)):
        out.append(f"--- {label}")
        for name, addr, n in live:
            vals = words_from(blk, addr, n)
            if n == 1:
                v = vals[0]
                out.append(f"{name:16s} @0x{addr:08x} = " + ("FAIL" if v is None else f"0x{v:08x}"))
                continue
            out.append(f"{name} @0x{addr:08x}:")
            for f, v in zip(FIELDS, vals):
                if v is None:
                    s = "FAIL"
                elif f.startswith("csr"):
                    s = f"0x{v:08x}  [{flags(v, CSR_FLAGS)}]"
                elif f == "dhcsr_at_boot":
                    s = f"0x{v:08x}  [{flags(v, DHCSR_FLAGS)}]"
                else:
                    s = f"0x{v:08x}  ({v})"
                out.append(f"    {f:14s} {s}")
    check_pattern("g_sram_pattern", words_from(second, sym["g_sram_pattern"], PATTERN_WORDS), 0x5A5A0000, out)
    check_pattern("g_ccm_pattern", words_from(second, sym["g_ccm_pattern"], PATTERN_WORDS), 0xCC5A0000, out)

    rc2, blocks2 = run_ocd([f"mdw 0x{BKPSRAM:08x} {PATTERN_WORDS}"], raw_log)
    out.append(f"session 2 (backup SRAM) exit={rc2}")
    check_pattern("backup SRAM", words_from(blocks2, BKPSRAM, PATTERN_WORDS), 0xBB5A0000, out)

    text = "\n".join(out)
    print(text)
    with open(log, "a") as fh:
        fh.write(text + "\n")


if __name__ == "__main__":
    main()
